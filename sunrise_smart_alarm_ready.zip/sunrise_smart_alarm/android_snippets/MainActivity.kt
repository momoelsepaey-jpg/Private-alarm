// ضعه في android/app/src/main/kotlin/<مسار حزمتك>/MainActivity.kt
// وغيّر سطر package ليطابق applicationId عندك.
package com.example.sunrise_smart_alarm

import android.app.KeyguardManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.media.RingtoneManager
import android.net.Uri
import android.os.Build
import android.os.PowerManager
import android.view.WindowManager
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel

class MainActivity : FlutterActivity() {
    private val channel = "sunrise/alarm_mode"
    private var pickResult: MethodChannel.Result? = null
    private var screenOffReceiver: BroadcastReceiver? = null

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)
        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, channel)
            .setMethodCallHandler { call, result ->
                when (call.method) {
                    "start" -> {
                        startMode(call.argument<Boolean>("prevent") ?: true)
                        result.success(null)
                    }
                    "stop" -> { stopMode(); result.success(null) }
                    "pickRingtone" -> {
                        pickResult = result
                        val i = Intent(RingtoneManager.ACTION_RINGTONE_PICKER)
                        i.putExtra(RingtoneManager.EXTRA_RINGTONE_TYPE, RingtoneManager.TYPE_ALARM)
                        i.putExtra(RingtoneManager.EXTRA_RINGTONE_SHOW_SILENT, false)
                        startActivityForResult(i, 4711)
                    }
                    else -> result.notImplemented()
                }
            }
    }

    @Suppress("DEPRECATION")
    private fun startMode(prevent: Boolean) {
        // يظهر فوق شاشة القفل ويشغّل الشاشة ويبقيها مضاءة
        if (Build.VERSION.SDK_INT >= 27) {
            setShowWhenLocked(true); setTurnScreenOn(true)
        } else {
            window.addFlags(
                WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or
                WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON)
        }
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        if (Build.VERSION.SDK_INT >= 26) {
            (getSystemService(Context.KEYGUARD_SERVICE) as KeyguardManager)
                .requestDismissKeyguard(this, null)
        }
        if (!prevent) return
        // تثبيت الشاشة: يمنع زر الرئيسية/الأخيرة (يطلب تأكيداً مرة واحدة)
        try { startLockTask() } catch (_: Exception) {}
        // زر القفل: عند إطفاء الشاشة نشغّلها ونعيد التطبيق للواجهة فوراً
        if (screenOffReceiver == null) {
            screenOffReceiver = object : BroadcastReceiver() {
                override fun onReceive(c: Context, i: Intent) {
                    val pm = c.getSystemService(Context.POWER_SERVICE) as PowerManager
                    val wl = pm.newWakeLock(
                        PowerManager.SCREEN_BRIGHT_WAKE_LOCK or
                        PowerManager.ACQUIRE_CAUSES_WAKEUP, "sunrise:wake")
                    wl.acquire(10_000)
                    val back = Intent(c, MainActivity::class.java)
                    back.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or
                        Intent.FLAG_ACTIVITY_REORDER_TO_FRONT or
                        Intent.FLAG_ACTIVITY_SINGLE_TOP)
                    c.startActivity(back)
                }
            }
            registerReceiver(screenOffReceiver, IntentFilter(Intent.ACTION_SCREEN_OFF))
        }
    }

    @Suppress("DEPRECATION")
    private fun stopMode() {
        screenOffReceiver?.let { try { unregisterReceiver(it) } catch (_: Exception) {} }
        screenOffReceiver = null
        try { stopLockTask() } catch (_: Exception) {}
        window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
    }

    @Suppress("DEPRECATION")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        if (requestCode == 4711) {
            val uri = data?.getParcelableExtra<Uri>(RingtoneManager.EXTRA_RINGTONE_PICKED_URI)
            if (resultCode == RESULT_OK && uri != null) {
                val title = RingtoneManager.getRingtone(this, uri)?.getTitle(this) ?: "نغمة"
                pickResult?.success(mapOf("uri" to uri.toString(), "name" to title))
            } else pickResult?.success(null)
            pickResult = null
        } else super.onActivityResult(requestCode, resultCode, data)
    }

    override fun onDestroy() { stopMode(); super.onDestroy() }
}
