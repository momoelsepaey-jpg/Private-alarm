import 'dart:async';
import 'dart:math' as m;
import 'package:flutter/material.dart';
import 'package:screen_brightness/screen_brightness.dart';
import 'package:wakelock_plus/wakelock_plus.dart';
import '../captcha/captchas.dart';
import '../core/sunrise_modes.dart';
import '../services/alarm_audio.dart';
import '../services/alarm_mode.dart';
import '../services/alarm_service.dart';
import '../services/storage.dart';

const _maxDips = 2; // خفض الصوت: دقيقة ثم دقيقة ثانية
const _dipSeconds = 60;

/// تظهر فور بدء التنبيه: ضوء الشروق + صوت متدرّج + تبديل الوضع + كابتشا + خفض الصوت.
class WakeScreen extends StatefulWidget {
  const WakeScreen({super.key});
  /// لمنع فتح شاشتين فوق بعض عند وصول إشعار إعادة التنبيه.
  static bool active = false;
  @override
  State<WakeScreen> createState() => _WakeScreenState();
}

class _WakeScreenState extends State<WakeScreen> {
  int _tick = 0;
  final _audio = AlarmAudio();
  AlarmSettings _s = AlarmSettings();
  LightWindow? _win;
  late final DateTime _startedAt;
  Timer? _timer;
  double _p = 0;
  Color _color = const Color(0xFF280000);
  bool _captcha = false;
  int _dips = 0;

  @override
  void initState() {
    super.initState();
    WakeScreen.active = true;
    _startedAt = DateTime.now();
    _init();
  }

  Future<void> _init() async {
    _s = await Storage.loadSettings();
    _win = await Storage.loadPlan();
    await WakelockPlus.enable();
    await AlarmMode.start(prevent: _s.preventLock);
    await AlarmService.snooze(2); // إعادة تنبيه تلقائية إن أُغلق التطبيق
    await _audio.start(rampSeconds: _s.rampSeconds, source: soundSourceFor(_s));
    _timer = Timer.periodic(const Duration(seconds: 1), (_) {
      _update();
      if (++_tick % 120 == 0) AlarmService.snooze(2); // نجدّدها طالما الشاشة مفتوحة
    });
    _update();
  }

  void _update() {
    final now = DateTime.now();
    final fromSun = _win?.progressAt(now) ?? 0;
    final fromRamp =
        (now.difference(_startedAt).inSeconds / _s.rampSeconds).clamp(0.0, 1.0);
    final p = m.max(fromSun, fromRamp);
    final b = (0.05 + 0.95 * brightnessCurve(p)).clamp(0.05, 1.0);
    ScreenBrightness().setApplicationScreenBrightness(b).catchError((_) {});
    if (mounted) {
      setState(() {
        _p = p;
        _color = lightColor(p);
      });
    }
  }

  void _dip() {
    if (_dips >= _maxDips || _audio.dipping) return;
    _audio.dip(const Duration(seconds: _dipSeconds));
    setState(() => _dips++);
  }

  Future<void> _switchMode(SunriseMode mode) async {
    _s.mode = mode;
    await Storage.saveSettings(_s);
    final plan = AlarmService.buildPlan(
        _s, DateTime.now().subtract(const Duration(hours: 12)));
    if (plan != null) {
      await Storage.savePlan(plan.light.start, plan.light.end);
      _win = plan.light;
    }
    _update();
  }

  void _dismiss() {
    if (_s.captchas.isEmpty) {
      _finish();
    } else {
      setState(() => _captcha = true);
    }
  }

  Future<void> _snooze() async {
    await _audio.stop();
    await AlarmService.snooze(_s.snoozeMinutes);
    await _cleanup();
    if (mounted) Navigator.of(context).maybePop();
  }

  Future<void> _finish() async {
    await _audio.stop();
    await AlarmService.cancel();
    await _cleanup();
    if (mounted) Navigator.of(context).maybePop();
  }

  Future<void> _cleanup() async {
    _timer?.cancel();
    await AlarmMode.stop();
    await WakelockPlus.disable();
    ScreenBrightness().resetApplicationScreenBrightness().catchError((_) {});
  }

  @override
  void dispose() {
    WakeScreen.active = false;
    _timer?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final now = DateTime.now();
    final dark = _color.computeLuminance() < 0.35;
    final fg = dark ? Colors.white : Colors.black87;
    final dipping = _audio.dipping;
    return PopScope(
      canPop: false,
      child: Scaffold(
        backgroundColor: _color,
        body: SafeArea(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(20),
            child: ConstrainedBox(
              constraints: BoxConstraints(
                  minHeight: MediaQuery.of(context).size.height - 80),
              child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                Text(
                  '${now.hour.toString().padLeft(2, '0')}:${now.minute.toString().padLeft(2, '0')}',
                  style: TextStyle(fontSize: 72, fontWeight: FontWeight.w300, color: fg),
                ),
                Text(modeSpecs[_s.mode]!.label, style: TextStyle(color: fg, fontSize: 18)),
                Text('${(_p * 100).round()}%', style: TextStyle(color: fg.withOpacity(.7))),
                const SizedBox(height: 20),
                if (_captcha)
                  CaptchaFlow(settings: _s, onSuccess: _finish)
                else
                  Wrap(
                    spacing: 8,
                    alignment: WrapAlignment.center,
                    children: [
                      for (final md in SunriseMode.values)
                        ChoiceChip(
                          label: Text(modeSpecs[md]!.label),
                          selected: _s.mode == md,
                          onSelected: (_) => _switchMode(md),
                        ),
                    ],
                  ),
                const SizedBox(height: 16),
                OutlinedButton.icon(
                  onPressed: (_dips >= _maxDips || dipping) ? null : _dip,
                  style: OutlinedButton.styleFrom(
                      foregroundColor: fg, minimumSize: const Size.fromHeight(48)),
                  icon: const Icon(Icons.volume_down),
                  label: Text(dipping
                      ? 'الصوت مخفوض: ${_audio.dipSecondsLeft} ث'
                      : _dips >= _maxDips
                          ? 'استُنفد خفض الصوت'
                          : _dips == 0
                              ? 'خفض الصوت دقيقة'
                              : 'خفض الصوت دقيقة ثانية'),
                ),
                if (!_captcha) ...[
                  const SizedBox(height: 12),
                  Row(children: [
                    Expanded(
                      child: OutlinedButton(
                        onPressed: _snooze,
                        style: OutlinedButton.styleFrom(
                            foregroundColor: fg, minimumSize: const Size.fromHeight(56)),
                        child: Text('غفوة ${_s.snoozeMinutes} د'),
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: FilledButton(
                        onPressed: _dismiss,
                        style: FilledButton.styleFrom(
                            minimumSize: const Size.fromHeight(56)),
                        child: const Text('إيقاف'),
                      ),
                    ),
                  ]),
                ],
              ]),
            ),
          ),
        ),
      ),
    );
  }
}
