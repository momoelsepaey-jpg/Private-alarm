import 'dart:convert';
import 'dart:typed_data';
import 'package:google_mlkit_image_labeling/google_mlkit_image_labeling.dart';
import 'package:image/image.dart' as im;
import 'package:image_picker/image_picker.dart';
import 'package:shared_preferences/shared_preferences.dart';

class CupResult {
  final bool ok;
  final String message;
  const CupResult(this.ok, this.message);
}

/// تعرّف على كوب الشاي على الجهاز (بدون إنترنت):
///  1) ML Kit يتأكد أن الصورة تحوي كوباً/قدحاً.
///  2) توقيع لوني (هيستوغرام) للكوب المسجَّل يُقارَن بالصورة الجديدة.
///  3) كل نجاح يضيف عيّنة جديدة فيتحسّن التعرف مع الوقت.
/// الكاميرا فقط (لا معرض) حتى لا تُستخدم صورة قديمة.
class TeaCupRecognizer {
  static const double labelConfidence = 0.55;
  static const double similarityThreshold = 0.40; // عدّله حسب تجربتك
  static const int maxRefs = 6;
  static const _cupWords = {
    'cup', 'mug', 'teacup', 'coffee cup', 'drinkware', 'saucer', 'tea'
  };
  static const _key = 'cup_refs';

  static Future<XFile?> _capture() => ImagePicker()
      .pickImage(source: ImageSource.camera, imageQuality: 80, maxWidth: 1024);

  static Future<bool> _looksLikeCup(String path) async {
    final labeler =
        ImageLabeler(options: ImageLabelerOptions(confidenceThreshold: 0.4));
    try {
      final labels = await labeler.processImage(InputImage.fromFilePath(path));
      return labels.any((l) =>
          _cupWords.contains(l.label.toLowerCase()) &&
          l.confidence >= labelConfidence);
    } finally {
      await labeler.close();
    }
  }

  /// هيستوغرام 4×4×4 للجزء الأوسط من الصورة (حيث يكون الكوب غالباً).
  static List<double> signature(Uint8List bytes) {
    var img = im.decodeImage(bytes)!;
    final w = img.width, h = img.height;
    img = im.copyCrop(img,
        x: (w * 0.2).round(), y: (h * 0.2).round(),
        width: (w * 0.6).round(), height: (h * 0.6).round());
    img = im.copyResize(img, width: 48, height: 48);
    final bins = List<double>.filled(64, 0);
    for (var y = 0; y < img.height; y++) {
      for (var x = 0; x < img.width; x++) {
        final p = img.getPixel(x, y);
        final r = p.r.toInt() >> 6, g = p.g.toInt() >> 6, b = p.b.toInt() >> 6;
        bins[r * 16 + g * 4 + b] += 1;
      }
    }
    final total = img.width * img.height;
    return bins.map((v) => v / total).toList();
  }

  static double intersection(List<double> a, List<double> b) {
    var s = 0.0;
    for (var i = 0; i < a.length; i++) {
      s += a[i] < b[i] ? a[i] : b[i];
    }
    return s;
  }

  static Future<List<List<double>>> _load() async {
    final p = await SharedPreferences.getInstance();
    return (p.getStringList(_key) ?? [])
        .map((e) => (jsonDecode(e) as List).map((x) => (x as num).toDouble()).toList())
        .toList();
  }

  static Future<void> _save(List<List<double>> refs) async {
    final p = await SharedPreferences.getInstance();
    await p.setStringList(_key, refs.map(jsonEncode).toList());
  }

  static Future<int> refCount() async => (await _load()).length;

  /// تسجيل الكوب (مرة واحدة، ويمكن الإعادة لتحسين التعرف).
  static Future<CupResult> enroll() async {
    final f = await _capture();
    if (f == null) return const CupResult(false, 'أُلغي التصوير');
    if (!await _looksLikeCup(f.path)) {
      return const CupResult(false, 'لم أتعرف على كوب في الصورة، قرّب الكوب وأضئ المكان');
    }
    final refs = await _load();
    refs.add(signature(await f.readAsBytes()));
    if (refs.length > maxRefs) refs.removeAt(1); // نُبقي العيّنة الأولى
    await _save(refs);
    return const CupResult(true, 'تم تسجيل كوب الشاي');
  }

  /// التحقق وقت التنبيه.
  static Future<CupResult> verify() async {
    final f = await _capture();
    if (f == null) return const CupResult(false, 'أُلغي التصوير');
    if (!await _looksLikeCup(f.path)) {
      return const CupResult(false, 'لم أتعرف على كوب، حاول مرة أخرى');
    }
    final refs = await _load();
    final sig = signature(await f.readAsBytes());
    if (refs.isEmpty) return const CupResult(true, 'تم (لم تسجّل كوبك بعد)');
    var best = 0.0;
    for (final r in refs) {
      final s = intersection(sig, r);
      if (s > best) best = s;
    }
    if (best >= similarityThreshold) {
      refs.add(sig); // تعلّم: عيّنة جديدة من الكوب نفسه
      if (refs.length > maxRefs) refs.removeAt(1);
      await _save(refs);
      return const CupResult(true, 'تم التعرف على كوبك');
    }
    return const CupResult(false, 'هذا لا يشبه كوبك المسجَّل');
  }
}
