import 'dart:async';
import 'package:flutter_foreground_task/flutter_foreground_task.dart';
import 'package:wakelock_plus/wakelock_plus.dart';
import '../core/smart_wake_planner.dart';
import '../core/sleep_stage_estimator.dart';
import 'alarm_service.dart';
import 'sleep_tracker.dart';
import 'storage.dart';

/// ينسّق الليلة: جدولة المنبه الإلزامي + تتبّع النوم + قرار الاستيقاظ الذكي.
class NightController {
  NightController({required this.onWake});
  final void Function() onWake;

  SleepTracker? _tracker;
  StreamSubscription<TrackerUpdate>? _sub;
  TrackerUpdate? last;
  WakeDecision? lastDecision;
  final _status = StreamController<String>.broadcast();
  Stream<String> get status => _status.stream;
  bool running = false;

  Future<WakePlan?> start(AlarmSettings s) async {
    final plan = AlarmService.buildPlan(s, DateTime.now());
    if (plan == null) return null;
    await AlarmService.schedule(plan); // شبكة أمان: يعمل حتى لو توقف التتبّع
    running = true;
    if (!s.smart) return plan;

    await _startForeground();
    await WakelockPlus.enable();
    _tracker = SleepTracker()..start();
    final planner = SmartWakePlanner(
      windowStart: plan.windowStart,
      deadline: plan.target,
      targetSleep: Duration(minutes: s.targetSleepMinutes),
    );
    _sub = _tracker!.updates.listen((u) async {
      last = u;
      final d = planner.decide(
        now: u.time,
        current: u.stage,
        previous: u.previous,
        minutesAsleep: u.minutesAsleep,
        lightProgress: plan.light.progressAt(u.time),
      );
      lastDecision = d;
      _status.add('${u.stage.name} • نوم ${u.minutesAsleep} د • ${d.reason}');
      if (d.wakeNow) {
        await Storage.addNight(NightRecord(
            u.time, u.minutesAsleep, u.stage.name, d.score));
        await stop();
        await AlarmService.cancel();
        onWake();
      }
    });
    return plan;
  }

  Future<void> _startForeground() async {
    try {
      FlutterForegroundTask.init(
        androidNotificationOptions: AndroidNotificationOptions(
          channelId: 'sleep_tracking',
          channelName: 'تتبّع النوم',
        ),
        iosNotificationOptions: const IOSNotificationOptions(),
        foregroundTaskOptions: ForegroundTaskOptions(
          eventAction: ForegroundTaskEventAction.nothing(),
        ),
      );
      await FlutterForegroundTask.startService(
        notificationTitle: 'تتبّع النوم يعمل',
        notificationText: 'المنبه الذكي نشط',
      );
    } catch (_) {/* التتبّع يستمر؛ الخدمة لتحسين البقاء حيّاً فقط */}
  }

  Future<void> stop() async {
    running = false;
    await _sub?.cancel();
    await _tracker?.stop();
    _tracker = null;
    try {
      await FlutterForegroundTask.stopService();
    } catch (_) {}
    await WakelockPlus.disable();
  }

  Future<void> cancelNight() async {
    await stop();
    await AlarmService.cancel();
  }
}
