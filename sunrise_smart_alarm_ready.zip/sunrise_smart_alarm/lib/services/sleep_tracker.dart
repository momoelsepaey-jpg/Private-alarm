import 'dart:async';
import 'dart:math' as m;
import 'package:sensors_plus/sensors_plus.dart';
import '../core/sleep_stage_estimator.dart';

class TrackerUpdate {
  final DateTime time;
  final SleepStage stage;
  final SleepStage previous;
  final int minutesAsleep;
  const TrackerUpdate(this.time, this.stage, this.previous, this.minutesAsleep);
}

/// يجمع حركة الجسم من مقياس التسارع (ضع الهاتف على المرتبة قرب الوسادة).
class SleepTracker {
  /// معامل تحويل الحركة إلى "counts" (عدّله إن كان التقدير حسّاساً/خاملاً).
  final double sensitivity;
  SleepTracker({this.sensitivity = 10});

  StreamSubscription? _sub;
  Timer? _timer;
  double _lastMag = 9.81;
  double _acc = 0;
  final List<double> activity = [];
  int? _onset;
  int _quietRun = 0;
  SleepStage _prev = SleepStage.awake;
  final _ctrl = StreamController<TrackerUpdate>.broadcast();
  Stream<TrackerUpdate> get updates => _ctrl.stream;

  int get minutesAsleep => _onset == null ? 0 : activity.length - _onset!;
  DateTime? startedAt;

  void start() {
    startedAt = DateTime.now();
    _sub = accelerometerEventStream(samplingPeriod: SensorInterval.normalInterval)
        .listen((e) {
      final mag = m.sqrt(e.x * e.x + e.y * e.y + e.z * e.z);
      _acc += (mag - _lastMag).abs();
      _lastMag = mag;
    });
    _timer = Timer.periodic(const Duration(minutes: 1), (_) => _tick());
  }

  void _tick() {
    activity.add(_acc * sensitivity);
    _acc = 0;
    final i = activity.length - 1;
    // بدء النوم: 10 دقائق متتالية من السكون
    if (_onset == null) {
      _quietRun = SleepStageEstimator.asleep(activity, i) ? _quietRun + 1 : 0;
      if (_quietRun >= 10) _onset = i - 9;
    }
    final stage = _onset == null
        ? SleepStage.awake
        : SleepStageEstimator.classify(activity, i, _onset!);
    _ctrl.add(TrackerUpdate(DateTime.now(), stage, _prev, minutesAsleep));
    _prev = stage;
  }

  Future<void> stop() async {
    await _sub?.cancel();
    _timer?.cancel();
    await _ctrl.close();
  }
}
